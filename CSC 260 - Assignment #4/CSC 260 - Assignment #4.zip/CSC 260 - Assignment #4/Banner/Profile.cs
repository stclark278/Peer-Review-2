using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class Profile
	{
		int UserID;

		public void GetUserProfile(int userID)
		{
			throw new NotImplementedException();
		}
	}
}
