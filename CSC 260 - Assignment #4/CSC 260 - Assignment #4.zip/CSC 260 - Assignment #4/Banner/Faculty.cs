using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class Faculty : Person
	{
		private static int UserID;
		private int UserRole;
		public int UserName;
		private string UserAddress;
		private string UserPhoneNumber;
		private string UserEmail;

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public int UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void ViewMySchedule()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses()
		{
			throw new NotImplementedException();
		}

		public boolean EnterGrades()
		{
			throw new NotImplementedException();
		}

		public void ViewCourseWaitlist()
		{
			throw new NotImplementedException();
		}

		public boolean ManagePrerequisits()
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int UserID)
		{
			throw new NotImplementedException();
		}

		public Faculty(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
