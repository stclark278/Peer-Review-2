using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class Student : Person
	{
		private static int UserID;
		private int UserRole;
		public string UserName;
		private string UserAddress;
		private string UserPhoneNumber;
		private string UserEmail;

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void PrepareForRegistration()
		{
			throw new NotImplementedException();
		}

		public boolean RegisterForClasses()
		{
			throw new NotImplementedException();
		}

		public void PlanAhead()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses()
		{
			throw new NotImplementedException();
		}

		public void ViewRegistrationInformation()
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int userID)
		{
			throw new NotImplementedException();
		}

		public Student(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
