using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public abstract class Person
	{
		private static int UserID;
		private int UserRole;
		private string UserName;

		public void BrowseCourses()
		{
			throw new NotImplementedException();
		}
	}
}
