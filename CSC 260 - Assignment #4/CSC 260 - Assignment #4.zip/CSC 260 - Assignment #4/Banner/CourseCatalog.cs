using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class CourseCatalog
	{
		int Term;
		string University;
		string Location;
		string Subject;
		int CourseNumber;
		string CourseName;
		string CourseSection;
		int CRN;
		int Credits;
		string Instructor;
		string Days;
		int SeatsAvailable;
		int SeatsFilled;

		public void SearchCourses(int Term, string University, string Location, string Subject, int CourseNumber)
		{
			throw new NotImplementedException();
		}

		public void ViewCourse()
		{
			throw new NotImplementedException();
		}
	}
}
