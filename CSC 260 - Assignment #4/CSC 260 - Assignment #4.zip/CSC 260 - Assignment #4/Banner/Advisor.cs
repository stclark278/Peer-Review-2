using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class Advisor : Person
	{
		private static int UserID;
		private int UserRole;
		public string UserName;
		private string UserAddress;
		private string UserPhoneNumber;
		private string UserEmail;

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public int UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void ViewAdviseeList()
		{
			throw new NotImplementedException();
		}

		public void RemoveRegistrationHolds()
		{
			throw new NotImplementedException();
		}

		public void ViewStudentProfiles()
		{
			throw new NotImplementedException();
		}

		public void EvaluateAdviseesDegreeProgress()
		{
			throw new NotImplementedException();
		}

		public void ViewAdviseesCurrentRegistration()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses()
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int UserID)
		{
			throw new NotImplementedException();
		}

		public Advisor(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
