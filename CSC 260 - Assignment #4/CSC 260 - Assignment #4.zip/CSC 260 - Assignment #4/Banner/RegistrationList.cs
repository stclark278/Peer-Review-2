using System;
using System.Collections.Generic;
using System.Text;

namespace CSC 260 - Assignment #4.Banner
{
	public class RegistrationList : CourseList
	{
		int Term;
		string CourseName;
		int CRN;
		string CourseSection;

		public boolean SaveList()
		{
			throw new NotImplementedException();
		}

		public void EditList()
		{
			throw new NotImplementedException();
		}

		public void DeleteList()
		{
			throw new NotImplementedException();
		}

		public void AddCourse()
		{
			throw new NotImplementedException();
		}

		public void DeleteCourse()
		{
			throw new NotImplementedException();
		}
	}
}
