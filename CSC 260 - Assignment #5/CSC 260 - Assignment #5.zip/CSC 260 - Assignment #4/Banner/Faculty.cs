using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class Faculty : Person
	{

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		private int UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		private string UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		private string UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		private int UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void ViewMySchedule()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses(int UserID, string UserRole)
		{
			throw new NotImplementedException();
		}

		public bool EnterGrades()
		{
			throw new NotImplementedException();
		}

		public void ViewCourseWaitlist()
		{
			throw new NotImplementedException();
		}

		public bool ManagePrerequisits()
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int UserID)
		{
			throw new NotImplementedException();
		}

		public Faculty(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
