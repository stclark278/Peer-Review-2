using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class RegistrationList : CourseList
	{
		int Term;
		string CourseName;
		int CRN;
		string CourseSection;

		public bool SaveList()
		{
			throw new NotImplementedException();
		}

		public void EditList()
		{
			throw new NotImplementedException();
		}

		public void DeleteList()
		{
			throw new NotImplementedException();
		}

		public void AddCourse()
		{
			throw new NotImplementedException();
		}

		public override bool DeleteCourse()
		{
			throw new NotImplementedException();
		}
	}
}
