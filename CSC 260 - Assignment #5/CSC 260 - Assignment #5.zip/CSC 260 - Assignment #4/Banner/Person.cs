using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public abstract class Person
	{
		private static int UserID;
		private string UserRole;
		private string UserName;

		public void BrowseCourses()
		{
			throw new NotImplementedException();
		}
	}
}
