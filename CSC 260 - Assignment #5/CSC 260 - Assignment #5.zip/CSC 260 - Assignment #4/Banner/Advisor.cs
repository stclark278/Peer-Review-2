using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class Advisor : Person
	{

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public int UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void ViewAdviseeList()
		{
			throw new NotImplementedException();
		}

		public void RemoveRegistrationHolds()
		{
			throw new NotImplementedException();
		}

		public void ViewStudentProfiles()
		{
			throw new NotImplementedException();
		}

		public void EvaluateAdviseesDegreeProgress()
		{
			throw new NotImplementedException();
		}

		public void ViewAdviseesCurrentRegistration()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses(int UserID, string UserRole, int StudentID)
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int UserID)
		{
			throw new NotImplementedException();
		}

		public Advisor(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
