using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class Student : Person
	{

		protected int UserID
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string UserRole
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		private string UserName
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		private int UserAddress
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		private string UserPhoneNumber
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		private string UserEmail
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public void PrepareForRegistration()
		{
			throw new NotImplementedException();
		}

		public bool RegisterForClasses()
		{
			throw new NotImplementedException();
		}

		public void PlanAhead()
		{
			throw new NotImplementedException();
		}

		public void BrowseCourses(int UserID, int UserRole)
		{
			throw new NotImplementedException();
		}

		public void ViewRegistrationInformation()
		{
			throw new NotImplementedException();
		}

		public void ViewProfile(int userID)
		{
			throw new NotImplementedException();
		}

		public Student(int UserID, int UserRole, string UserName)
		{
			throw new NotImplementedException();
		}
	}
}
