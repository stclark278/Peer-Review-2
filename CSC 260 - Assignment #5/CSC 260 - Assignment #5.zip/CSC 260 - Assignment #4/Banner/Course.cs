using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class Course
	{
		int Term;
		string University;
		string Location;
		string Subject;
		int CourseNumber;
		string CourseName;
		string CourseSection;
		int CRN;
		int Credits;
		string Instructor;
		string Days;
		int SeatsAvailable;
		int SeatsFilled;
		int CourseSelected;

		public Course(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowClassDetails(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowCourseDescription(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowInstructor(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowWaitlist(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowRestrictions(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowPrerequisites(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowCorequisits(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowCrossListedCourses(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowGenEdHonorsIndicator(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowCatalogInfo(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public void ShowFees(int Term, int CRN)
		{
			throw new NotImplementedException();
		}

		public int SelectCourse()
		{
			throw new NotImplementedException();
		}
	}
}
