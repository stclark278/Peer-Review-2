using System;
using System.Collections.Generic;
using System.Text;

namespace CSC_260_Assignment_4
{
	public class Profile
	{
		int UserID;

		public void GetUserProfile(int userID)
		{
			throw new NotImplementedException();
		}
	}
}
